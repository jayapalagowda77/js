/*
	Associative Array: in javascript is having a key-value pair.
*/ 

// Example

var associativeArray = {
	name: "Gokul",
	age: 25,
	role: "UI Developer"
};

console.log(associativeArray.name); // Gokul